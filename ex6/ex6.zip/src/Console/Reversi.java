package Console;

public class Reversi {
    /**
     * Main.
     *
     * @param args empty.
     */
    public static void main(String[] args) {
        Gameflow game = new Gameflow();
        game.run();
    }
}
