/* OMER BARAK       313264053 */
/* HODAYA KOSLOWSKY 313377673 */

#include <iostream>
#include "point.h"

using namespace std;

Point::Point(int x, int y) : x_(x), y_(y) {}

Point::~Point() {}

int Point::getX() const {
  return x_;
}

int Point::getY() const {
  return y_;
}

void Point::setX(int x) {
  x_ = x;
}

void Point::setY(int y) {
  y_ = y;
}

bool Point::operator==(const Point &point) const {
  return x_ == point.getX() && y_ == point.getY();
}

bool Point::operator!=(const Point &point) const {
  return x_ != point.getX() || y_ != point.getY();
}

std::ostream &operator<<(std::ostream &out, Point const &point) {
  return out << "(" << point.getX() + 1 << ", " << point.getY() + 1 << ")";
}
